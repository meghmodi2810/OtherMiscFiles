<?php
$conn = new mysqli("localhost", "root", "6640", "db_ajax") or die("Can't connect to this network! Error!");