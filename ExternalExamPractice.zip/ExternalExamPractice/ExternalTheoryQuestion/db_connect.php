<?php
$conn = new mysqli("localhost", "root", "6640", "db_external") or die("Cannot connect to database! Server down!");