<?php
require_once 'db_connect.php';
include_once 'base.php';

session_start();
if(!isset($_SESSION['name'])) {
    header("Location: index.php");
}
$stmt = $conn->prepare("SELECT * FROM restaurant");
$stmt->execute();

$res = $stmt->get_result();

echo "<TABLE border=1 cellpadding=20px>";
echo "<TR>";
echo "<TH>Name</TH>";
echo "<TH>Location</TH>";
echo "<TH>Capacity</TH>";
echo "<TH>Operations</TH>";
echo "</TR>";
while($row = $res->fetch_assoc()) {
    echo "<TR>";
    echo "<TD>" . $row['NAME'] . "</TD>";
    echo "<TD>" . $row['LOCATION'] . "</TD>";
    echo "<TD>" . $row['CAPACITY'] . "</TD>";
    echo "<td>"
    . "<a href='edit.php?name={$row['NAME']}'>Edit</a> "
    . " | "
    . "<a href='delete.php?name={$row['NAME']}'>Delete</a>"
    . "</td>";
    echo "</TR>";
}
echo "</TABLE>";

$stmt->close();
$conn->close();