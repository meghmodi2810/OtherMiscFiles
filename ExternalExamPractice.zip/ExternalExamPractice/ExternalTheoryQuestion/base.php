<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <style>
        li {
            display: inline;
            padding: 50px;
        }
        ul {
            align-content: center;
            list-style-type: none;
        }
    </style>
    <body>
        <ul>
            <li><a href="listing.php">Listing</a></li>
            <li><a href="review.php">Give Review</a></li>
            <li><a href="display.php">View Review</a></li>
        </ul>
    </body>
</html>
